﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DroppingStop : MonoBehaviour
{
    public GameObject blockSpawner;
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.name.StartsWith("ShadowParticle"))
        {
            if (this.GetComponent<Parent>().parentObject.GetComponent<BoxBlockActions>().GetCollided())
            {
                this.GetComponent<Parent>().parentObject.GetComponent<BoxBlockActions>().Delete(this.gameObject);
                return;
            }
            else
            {
                Destroy(collision.gameObject);
                return;
            }
        }
        this.GetComponent<Parent>().parentObject.GetComponent<BoxBlockActions>().Stop();
        blockSpawner.GetComponent<SpawnerBlock>().Moveover();
    }

}
