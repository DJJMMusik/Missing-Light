﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class SpawnerBlock : MonoBehaviour
{
    private int quadnumber = 2;
    public GameObject controller;
    public GameObject objects;
    public string parentName;
    public GameObject[] gameObjects;
    private float lastCollisionTime;
    private GameObject gO;
    private int blockcounter = 0;
    private GameObject[] blocks;
    public GameObject[] movementBorders = new GameObject[2];

    
    private void Start()
    {
        lastCollisionTime = 6f;
        Spawn();
        Moveover();
    }

    private void Update()
    {
        lastCollisionTime += Time.deltaTime;
    }

    private void Spawn()
    {
        float shift = (quadnumber - 1) * 0.5f;
        
        gO = new GameObject();
        if(parentName.Equals("BoxHolder")) gO.AddComponent<BoxBlockActions>();
        gO.name = parentName;
        gO.transform.parent = objects.transform;
        gO.transform.position = this.transform.position;

        blockcounter = 0;
        blocks = new GameObject[quadnumber * quadnumber];
        while (Random.value < 1f - 1f/(quadnumber * quadnumber)*blockcounter)
        {
            int ranObj = (int)(Random.value * gameObjects.Length);
            if (ranObj != gameObjects.Length)
            {
                GameObject randomObject = gameObjects.GetValue(ranObj) as GameObject;
                float spawnOption = Camera.main.orthographicSize - 1f;
                blocks[blockcounter] = Instantiate(randomObject, new Vector3(gameObject.transform.position.x, gameObject.transform.position.y, 0f), new Quaternion());
                blocks[blockcounter].transform.Rotate(new Vector3(0,0, 90 * (int) (Random.value * 2)));
                blocks[blockcounter].transform.parent = gO.transform;
                blocks[blockcounter].AddComponent<Parent>().parentObject = gO;
                if (parentName.Equals("BoxHolder")) blocks[blockcounter].GetComponent<DroppingStop>().blockSpawner = this.gameObject;
                blockcounter++;
            }
            

        }
        if (parentName.Equals("BoxHolder"))
        {
            gO.GetComponent<BoxBlockActions>().elements = blockcounter;
        }

        //Position anpassen speziell SpawnerBlock (quadnumber = 2)
        if (blockcounter == 1)
        {
            blocks[0].transform.position = new Vector3(gO.transform.position.x - 0.5f, gO.transform.position.y - 0.5f);
        }
        else if (blockcounter == 2)
        {
            blocks[0].transform.position = new Vector3(gO.transform.position.x - 0.5f, gO.transform.position.y - 0.5f);
            blocks[1].transform.position = new Vector3(gO.transform.position.x - 0.5f, gO.transform.position.y + 0.5f);
        }
        else if (blockcounter == 3)
        {
            blocks[0].transform.position = new Vector3(gO.transform.position.x - 0.5f, gO.transform.position.y - 0.5f);
            blocks[1].transform.position = new Vector3(gO.transform.position.x - 0.5f, gO.transform.position.y + 0.5f);
            blocks[2].transform.position = new Vector3(gO.transform.position.x + 0.5f, gO.transform.position.y - 0.5f);
        }
        else if (blockcounter == 4)
        {
            blocks[0].transform.position = new Vector3(gO.transform.position.x - 0.5f, gO.transform.position.y - 0.5f);
            blocks[1].transform.position = new Vector3(gO.transform.position.x - 0.5f, gO.transform.position.y + 0.5f);
            blocks[2].transform.position = new Vector3(gO.transform.position.x + 0.5f, gO.transform.position.y - 0.5f);
            blocks[3].transform.position = new Vector3(gO.transform.position.x + 0.5f, gO.transform.position.y + 0.5f);
        }
        gO.transform.localScale = new Vector3(0.8f,0.8f);
    }

    public void Moveover()
    {
        if (lastCollisionTime < 0.3f) return;
        if (lastCollisionTime < 4f)
        {
            controller.GetComponent<ScreenChanger>().GameOver();
        }
        gO.transform.localScale = new Vector3(1f, 1f);
        gO.transform.position = new Vector3(0f, 6f);
        gO.AddComponent<MoveDirection>();
        gO.GetComponent<MoveDirection>().direction = new Vector2(0, 1);
        gO.GetComponent<MoveDirection>().speed = 0.7f;
        gO.AddComponent<PlayerInput>();
        //Debug.Log(Screen.height/100000f);
        PlayerInput pI = gO.GetComponent<PlayerInput>();
        pI.cooldownreset = 0.3f;

        //pI.movementSpeed = Screen.height / 100000f;
        pI.movementSpeed = 1f;
        pI.borderLeft = movementBorders[0];
        pI.borderRight = movementBorders[1];
        pI.rotatable = true;


        // Move last element over
        Spawn();
        lastCollisionTime = 0f;
    }
}
