﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LaserShooter : MonoBehaviour
{
    public GameObject objects;
    public GameObject laserParticle;
    public GameObject[] candle;
    public GameObject controller;
    private float cooldown = 0;

    private void Update()
    {
        cooldown -= Time.deltaTime;
    }

    public void Shoot()
    {
        if (cooldown > 0) return;
        GameObject gO = Instantiate(laserParticle);
        gO.transform.parent = objects.transform;
        gO.GetComponent<GameEnderCandleLaser>().candleHolders = new GameObject[] {candle[0], candle[1]};
        gO.GetComponent<GameEnderCandleLaser>().controller = controller;
        cooldown = 2.5f;
    }
}
