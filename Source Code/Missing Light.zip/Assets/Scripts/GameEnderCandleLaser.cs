﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameEnderCandleLaser : MonoBehaviour
{
    public GameObject[] candleHolders;
    public GameObject controller;
    private int delayedType = 0;
    private float delay = 0;

    private void Update()
    {
        if (delayedType == 0) return;
        delay -= Time.deltaTime;
        if (delay < 0)
        {
            switch (delayedType)
            {
                case 1:
                    this.GetComponent<MoveDirection>().direction = new Vector2(-this.GetComponent<MoveDirection>().direction.y, -this.GetComponent<MoveDirection>().direction.x);
                    this.transform.Rotate(0, 0, 90);
                    break;
                case 2:
                    this.GetComponent<MoveDirection>().direction = new Vector2(this.GetComponent<MoveDirection>().direction.y, this.GetComponent<MoveDirection>().direction.x);
                    this.transform.Rotate(0, 0, 90);
                    break;
                default:
                    break;
            }

            delay = 0;
            delayedType = 0;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (gameObject.name.Equals("laserParticle(Clone)"))
        {
            GameObject gO = collision.gameObject;
            if (gO == candleHolders[1])
            {
                controller.GetComponent<ScreenChanger>().GameOver();
                foreach (GameObject candleHolder in candleHolders)
                {
                    candleHolder.SetActive(!candleHolder.activeSelf);
                }
            }
            else if (gO.name.StartsWith("boxwith"))
            {
                if (gO.name.StartsWith("boxwithdiagonal"))
                {
                    int rotation = (int)collision.gameObject.transform.rotation.eulerAngles.z;
                    rotation = rotation % 180;
                    if (rotation == 0)
                    {
                        delayedType = 1;
                    }
                    else
                    {
                        delayedType = 2;
                    }
                    delay = 0.34f;
                }
            }
            else if (gO.name.StartsWith("ShadowParticle"))
            {
                Destroy(gO);
                controller.GetComponent<ScreenChanger>().canvasElements[0].GetComponent<ScoreCounter>().Change(100);
            }

        }
    }
}
