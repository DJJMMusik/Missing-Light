﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ModeButton : MonoBehaviour
{
    public string chosenMode = "menue";
    public string description = "";
    public GameObject controller;
    void Start()
    {
        Button btn = this.GetComponent<Button>();
        btn.onClick.AddListener(TaskOnClick);
    }

    public void TaskOnClick()
    {
        controller.GetComponent<ModeController>().Change(chosenMode, description);
    }
}
