﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulbEffects : MonoBehaviour
{
    
    public GameObject lightEffect;

    public Transform spawn;
    public GameObject brokenLamp;
    public GameObject brokenEffect;
    public GameObject gameOver;
    
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (gameObject.name == "bulbOn")
        {
            Instantiate(brokenEffect);
            GameObject brLamp = Instantiate(brokenLamp, spawn.position, spawn.rotation);
            HingeJoint2D hjbrLamp = brLamp.AddComponent<HingeJoint2D>() as HingeJoint2D;
            hjbrLamp.connectedBody = brokenEffect.GetComponent<Rigidbody2D>();
            Destroy(lightEffect);
            gameOver.GetComponent<ScreenChanger>().GameOver();
            Destroy(gameObject);
        }
    }
}
