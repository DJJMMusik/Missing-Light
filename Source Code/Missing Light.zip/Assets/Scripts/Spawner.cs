﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    public GameObject objects;
    public GameObject[] gameObjects;
    public Vector3 moveDirSpe = new Vector3(1,0,1.85f);
    public bool xory;
    public GameObject[] spawnBorders;
    public float spawnOption;
    public int spawnTime = 1000;
    
    public int spawnTimer = 100;

    private void Start()
    {
        spawnOption = Camera.main.orthographicSize - 1f;
        if (spawnBorders.Length != 2) return;
        if (!xory)
        {
            float left = spawnBorders[0].transform.position.x;
            float right = spawnBorders[1].transform.position.x;
            spawnOption = (right - left) / 2;
            this.transform.position = new Vector3(left + spawnOption, this.transform.position.y);
            spawnOption = spawnOption - 1f;
        } 
        else
        {
            float left = spawnBorders[0].transform.position.y;
            float right = spawnBorders[1].transform.position.y;
            spawnOption = (right - left) / 2;
            this.transform.position = new Vector3(this.transform.position.x, right + spawnOption);
            spawnOption = spawnOption - 1f;
        }
    }

    // Update is called once per frame
    void Update()
    {
        spawnTimer--;
        if (spawnTimer <= 0)
        {
            spawnTimer = spawnTime;
            int ranObj = (int) (Random.value * gameObjects.Length);
            if (ranObj != gameObjects.Length)
            {
                GameObject randomObject = gameObjects.GetValue(ranObj) as GameObject;
                float spawnPositionX;
                float spawnPositionY;
                if (xory)
                {
                    spawnPositionX = gameObject.transform.position.x;
                    spawnPositionY = Random.value * spawnOption * 2f - spawnOption;
                } 
                else
                {
                    spawnPositionX = Random.value * spawnOption * 2f - spawnOption;
                    spawnPositionY = gameObject.transform.position.y;
                }

                GameObject gO = Instantiate(randomObject, new Vector3(spawnPositionX, spawnPositionY, 0f), new Quaternion());
                gO.AddComponent<MoveDirection>();
                gO.GetComponent<MoveDirection>().direction = new Vector2(moveDirSpe.x, moveDirSpe.y);
                gO.GetComponent<MoveDirection>().speed = moveDirSpe.z;
                gO.transform.parent = objects.transform;
            }
        }
    }

    public void emptyGameObjects()
    {
        gameObjects = new GameObject[0];
    }
}
