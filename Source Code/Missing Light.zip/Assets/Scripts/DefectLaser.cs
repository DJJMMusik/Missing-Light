﻿using UnityEngine;

public class DefectLaser : MonoBehaviour
{
    public GameObject laser;
    private float lasertimer;
    // Start is called before the first frame update
    void Start()
    {
        if (gameObject.transform.position.y > 1)
        {
            float shortTime = Random.value * 1.2f;
            lasertimer = shortTime;
            laser.GetComponent<DeathTimer>().lifeTime = shortTime;
            GameObject gO = Instantiate(laser, gameObject.transform.position, gameObject.transform.rotation);
            gO.transform.parent = this.transform;
        }
        else
        {
            float longTime = 13f;
            lasertimer = longTime;
            laser.GetComponent<DeathTimer>().lifeTime = longTime;
            GameObject gO = Instantiate(laser, gameObject.transform.position, gameObject.transform.rotation);
            gO.transform.parent = this.transform;
        }
    }

    void Update()
    {
        lasertimer -= Time.deltaTime;
        if (lasertimer <= -2.2f)
        {
            lasertimer = 1f;
            laser.GetComponent<DeathTimer>().lifeTime = lasertimer;
            GameObject gO = Instantiate(laser, gameObject.transform.position, gameObject.transform.rotation);
            gO.transform.parent = this.transform;
        }
    }
}
