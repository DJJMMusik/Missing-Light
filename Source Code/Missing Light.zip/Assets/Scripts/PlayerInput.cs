﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerInput : MonoBehaviour
{
    public InputAction wasd;
    public GameObject borderRight;
    public GameObject borderLeft;
    public float movementSpeed;
    public float cooldownreset = 0;

    public bool rotatable = false;
    private float cooldown = 0;

    // Start is called before the first frame update
    void Start()
    {
        wasd = new InputAction("Movement");
        wasd.AddCompositeBinding("Dpad")
            .With("Up", "<Keyboard>/w")
            .With("Down", "<Keyboard>/s")
            .With("Left", "<Keyboard>/a")
            .With("Right", "<Keyboard>/d");
        wasd.Enable();
    }

    // Update is called once per frame
    void Update()
    {
        cooldown -= Time.deltaTime;
        if (cooldown > 0) return;
        if (wasd.ReadValue<Vector2>().x == 0 && wasd.ReadValue<Vector2>().y == 0) return;
        Vector2 changes = new Vector2(Mathf.Sign(wasd.ReadValue<Vector2>().x), Mathf.Sign(wasd.ReadValue<Vector2>().y));
        if (wasd.ReadValue<Vector2>().x == 0) changes.x = 0;
        if (wasd.ReadValue<Vector2>().y == 0) changes.y = 0;
        cooldown = cooldownreset;

        float movement = changes.x * movementSpeed;// * Screen.height;
        //Debug.Log(Screen.height);
        float newXPos = transform.position.x + movement;
        
        if (newXPos < borderRight.transform.position.x - borderRight.transform.localScale.x && newXPos > borderLeft.transform.position.x + borderLeft.transform.localScale.x)
        {
            Vector3 inputVector = new Vector3(movement,0,0);
            transform.position = transform.position + inputVector;
        }

        if (rotatable) transform.Rotate(new Vector3(0, 0, 90 * changes.y));
    }
}
