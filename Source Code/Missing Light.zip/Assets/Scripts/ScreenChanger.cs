﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class ScreenChanger : MonoBehaviour
{
    public GameObject[] spawners;
    public GameObject[] canvasElements;
    public GameObject[] backgrounds;

    private int score;
    private int highScore;
    private float survivalTime;

    private bool collided = false;

    public void Update()
    {
        survivalTime += Time.deltaTime;
    }

    public void GameOver()
    {
        if (collided) return;
        collided = true;
        foreach (GameObject spawn in spawners) {
            if (spawn.name == "Spawner")
            {
                spawn.GetComponent<Spawner>().enabled = false;
            }
            else if (spawn.name == "BlockSpawner")
            {
                spawn.GetComponent<SpawnerBlock>().enabled = false;
            }
        }
        foreach (GameObject background in backgrounds)
        {
            background.SetActive(true);
            if (background.GetComponent<Looper>() != null)
            {
                background.GetComponent<Looper>().enabled = false;
            }
        }
        score = canvasElements[0].GetComponent<ScoreCounter>().score;
        //TODO highscore aus Datei laden
        canvasElements[0].GetComponent<ScoreCounter>().enabled = false;
        
        if (score > highScore)
        {
            highScore = score; //TODO Zeile entfernen
            //TODO Highscore abspeichern
            canvasElements[3].GetComponent<TextMeshProUGUI>().text =
            "Stats" + "\n" +
            (int) survivalTime + "s survived\n" +
            score + " points\n" +
            "" + "\n" +
            "New Highscore" + "\n" +
            highScore;
        } 
        else
        {
            canvasElements[3].GetComponent<TextMeshProUGUI>().text =
            "Stats" + "\n" +
            (int) survivalTime + "s survived\n" +
            score + " points\n" +
            "" + "\n" +
            "Highscore" + "\n" +
            highScore;
        }

        foreach (GameObject gameObject in canvasElements) {
            gameObject.SetActive(!gameObject.activeSelf);
        }
    }
}
