﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoxBlockActions : MonoBehaviour
{
    private bool collided = false;
    public int elements;
    public void Stop()
    {
        if (collided) return;
        this.GetComponent<MoveDirection>().enabled = false;
        this.GetComponent<PlayerInput>().enabled = false;
        collided = true;
    }

    public void Delete(GameObject child)
    {
        Destroy(child);
        elements--;
        if (elements == 0) Destroy(this.gameObject);
    }

    public bool GetCollided()
    {
        return collided;
    }
}
