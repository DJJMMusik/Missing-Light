﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveDirection : MonoBehaviour
{
    public float speed = 0.1f;
    public Vector2 direction = new Vector2(1,0);
    // Update is called once per frame
    void Update()
    {
        gameObject.transform.position = gameObject.transform.position - new Vector3(speed * Time.deltaTime * direction.x, speed * Time.deltaTime * direction.y, 0);
    }
}
