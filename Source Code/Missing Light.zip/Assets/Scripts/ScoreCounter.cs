﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class ScoreCounter : MonoBehaviour
{
    public int score = 0;
    private TextMeshProUGUI tMP;
    // Start is called before the first frame update
    void Start()
    {
        tMP = gameObject.GetComponent<TextMeshProUGUI>();
        tMP.text = "Score: " + score;
    }

    public void Change(int change)
    {
        score += change;
        if (score < 0) score = 0;
        tMP.text = "Score: " + score;
    }
}
