﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WallProp : MonoBehaviour
{
    public GameObject upperPart;
    public GameObject lowerPart;
    private GameObject uppergO;
    private GameObject lowergO;
    private float opening;
    private float scaleFactor = 0.1982914f;
    private MoveDirection mD;
    // Start is called before the first frame update
    void Start()
    {
        mD = this.GetComponent<MoveDirection>();
        opening = gameObject.transform.position.y;
        gameObject.transform.position = new Vector3(gameObject.transform.position.x, -0.1f, gameObject.transform.position.z);
        if (Mathf.Abs(opening) > 3)
        {
            if (opening > 0)
            {
                float lowerScale = 3.7f;
                float lowerPosition = -4.7f + lowerScale / 2f;
                lowergO = Instantiate(lowerPart, new Vector3(gameObject.transform.position.x, lowerPosition, gameObject.transform.position.z), lowerPart.transform.rotation);
                lowergO.transform.localScale = new Vector3(lowerPart.transform.localScale.x, lowerScale * scaleFactor, lowerPart.transform.localScale.z);
                lowergO.transform.parent = this.transform;
            }
            else
            {
                float upperScale = 3.4f;
                float upperPosition = 4.4f - upperScale / 2f;
                uppergO = Instantiate(upperPart, new Vector3(gameObject.transform.position.x, upperPosition, gameObject.transform.position.z), upperPart.transform.rotation);
                uppergO.transform.localScale = new Vector3(upperPart.transform.localScale.x, upperScale * scaleFactor, upperPart.transform.localScale.z);
                uppergO.transform.parent = this.transform;
            }
        } 
        else
        {
            float upperScale = 3.4f - opening;
            float upperPosition = 4.4f - upperScale / 2f;
            uppergO = Instantiate(upperPart, new Vector3(gameObject.transform.position.x, upperPosition, gameObject.transform.position.z), upperPart.transform.rotation);
            uppergO.transform.localScale = new Vector3(upperPart.transform.localScale.x, upperScale * scaleFactor, upperPart.transform.localScale.z);
            float lowerScale = 3.7f + opening;
            float lowerPosition = -4.7f + lowerScale / 2f;
            lowergO = Instantiate(lowerPart, new Vector3(gameObject.transform.position.x, lowerPosition, gameObject.transform.position.z), lowerPart.transform.rotation);
            lowergO.transform.localScale = new Vector3(lowerPart.transform.localScale.x, lowerScale * scaleFactor, lowerPart.transform.localScale.z);
            lowergO.transform.parent = this.transform;
            uppergO.transform.parent = this.transform;
        }
    }
}
