﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class ModeController : MonoBehaviour
{
    public GameObject[] modes;
    public GameObject[] infos;
    private string chosenMode = "menue";

    public void Change(string newMode, string description)
    {
        if (newMode.Equals(chosenMode) || newMode.Equals("menue")) return;

        infos[0].GetComponent<SceenSwitch>().sceneName = newMode;
        infos[1].GetComponent<TextMeshProUGUI>().text = newMode;
        infos[2].GetComponent<TextMeshProUGUI>().text = description;

        if (chosenMode.Equals("menue"))
        {
            infos[0].GetComponent<Button>().interactable = true;
            infos[1].SetActive(true);
            infos[2].SetActive(true);
        }

        Activate(newMode);
        chosenMode = newMode;
    }

    private void Activate(string newMode)
    {
        foreach (GameObject mode in modes)
        {
            string name = mode.name;
            if (name.StartsWith(chosenMode))
            {
                if (name.Equals(chosenMode + "Normal"))
                {
                    mode.SetActive(true);
                }
                else if (name.Equals(chosenMode + "Chosen"))
                {
                    mode.SetActive(false);
                }
            }
            if (name.StartsWith(newMode))
            {
                if (name.Equals(newMode + "Normal"))
                {
                    mode.SetActive(false);
                }
                else if (name.Equals(newMode + "Chosen"))
                {
                    mode.SetActive(true);
                }
            }
        }
    }
}
