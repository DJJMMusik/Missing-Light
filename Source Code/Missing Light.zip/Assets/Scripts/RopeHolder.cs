﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RopeHolder : MonoBehaviour
{
    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.name == "wheel") WheelCollision(other.gameObject);
    }

    void OnCollisionStay2D(Collision2D other)
    {
        if (other.gameObject.name == "wheel") WheelCollision(other.gameObject);
    }

    void WheelCollision(GameObject Wheel)
    {
        if (Wheel.transform.position.y - gameObject.transform.position.y > -0.1)
        {
            gameObject.GetComponent<Rigidbody2D>().velocity = gameObject.GetComponent<Rigidbody2D>().velocity + new Vector2(0, 5);
        }
    }
}
